import logic

if __name__ == '__main__':
    #Initialize game
    mat = logic.start_game()

    #read user input while game continues
    while(True):
        #ask for user action
        user_action=input("Press The Command:")

        if(user_action=='W' or user_action=='w'):
            #Invoke move_up function
            mat,changed_flag = logic.move_up(mat)

            #get the current status and print result
            status = logic.get_current_status(mat)
            print(status)

            #verify if GAME NOT OVER then continue
            if status=='GAME NOT OVER':
                logic.add_new_2(mat)
            else:
                break
        elif(user_action in ('S','s')):
            mat,changed_flag=logic.move_down(mat)
            status=logic.get_current_status(mat)
            if status=='GAME NOT OVER':
                logic.add_new_2(mat)
            else:
                break
        elif(user_action in ('A','a')):
            print('Move left')
            mat,changed_flag=logic.move_left(mat)
            status=logic.get_current_status(mat)
            print('status:',status)
            if status=='GAME NOT OVER':
                logic.add_new_2(mat)
            else:
                break
        elif(user_action in ('D','d')):
            mat,changed_flag=logic.move_right(mat)
            status=logic.get_current_status(mat)
            if status=='GAME NOT OVER':
                logic.add_new_2(mat)
            else:
                break
        else:
            print("Invald Command, Valid commands are W/S/A/D Upper/Down/Left/Right") 
        print(mat[0])
        print(mat[1])
        print(mat[2])
        print(mat[3])

