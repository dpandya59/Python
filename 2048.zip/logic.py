#logic.py to be used in 2048.py

#importing random package to generate random numbers
import random

#function to initialize the game/grid at the start

def start_game():
    #declaring emptylist and then appending 4 list each with element as 0
    mat=[]
    for i in range(4):
        mat.append([0]*4)
    
    #diplay controals for user
    print("Use below command to play game:")
    print("'W' or 'w' to move UP")
    print("'S' or 's' to move DOWN")
    print("'A' or 'a' to move LEFT")
    print("'D' or 'd' to move RIGHT")

    #initialize random cell with first 2 in grid
    add_new_2(mat)
    print(mat)
    return mat

#Function to assign 2 to empty grid within matrix
def add_new_2(mat):
    #choosing random place within the matrix for assigning 2
    r = random.randint(0,3)
    c = random.randint(0,3)

    #check if random selected cell is blank/ not if not choose another random cell
    while(mat[r][c]!=0):
        r=random.randint(0,3)
        c=random.randint(0,3)
    
    #we will replace 2 at that empty cell
    mat[r][c]=2

#Function to get current status of matrix
def get_current_status(mat):
    var_status='LOST'
    #check for a cell with 20248 
    for i in range (4):
        for j in range(4):
            if mat[i][j]==2048:
                var_status='WON'
            elif mat[i][j]==0:
                var_status='GAME NOT OVER'
    
    #check if any possible cell merge
    for i in range(3):
        for j in range(3):
            if (mat[i][j]==mat[i][j+1]) or (mat[i][j]==mat[i+1][j]):
                var_status='GAME NOT OVER'
    
    #check for last row and column 
    for j in range(3):
        if mat[3][j]==mat[3][j+1]:
            var_status='GAME NOT OVER'
        elif mat[j][3]==mat[j+1][3]:
            var_status='GAME NOT OVER'
    
    #else
    return var_status

#Compress matrix Move left all non zero cells
def compress_matrix(mat):

    #variable to hold initial position
    changed =False
    #declaring empty matrix to copy non zero cells from original matrix 
    new_mat=[]

    #initialize with zero
    for i in range (4):
        new_mat.append([0]*4)

    #loop for each row
    for i in range(4):
        #reset position for each row
        pos=0

        #for each column
        for j in range(4):
            
            #verfiy grid for non zero element
            if(mat[i][j]!=0):
                #move non empty cell to left available slot at pos
                new_mat[i][pos]=mat[i][j]
                if(j!=pos):
                    changed=True
                pos += 1
    return new_mat,changed

#Function to merge consecutive similar numbers
def merge(mat):
    changed=False

    #Verify for two consecutive number
    for i in range(4):
        for j in range(3):
            #verify if two consecutive non zero numbers are same
            if (mat[i][j]==mat[i][j+1]) and mat[i][j]!=0:
                #move left the number 
                mat[i][j]= mat[i][j]*2
                #empty next cell value
                mat[i][j+1]=0
                changed=True
    return mat, changed

#Reverse the matrix
def reverse(mat):
    new_mat=[]
    
    for i in range(4):
        new_mat.append([])
        for j in range(4):
            new_mat[i].append(mat[i][3-j])
    
    return new_mat

#Transpose by interchanging matrix row and columns
def transpose(mat):
    new_mat=[]
    for i in range(4):
        new_mat.append([])
        for j in range(4):
            new_mat[i].append(mat[j][i])
    return new_mat

#function to perform swipe left
def move_left(grid):
    changed =False
    #first compress the matrix
    new_grid,changed1 = compress_matrix(grid)

    #merge the cells
    new_grid,changed2 = merge(new_grid)

    changed = changed1 or changed2

    #again compress after merging
    new_grid,changed = compress_matrix(new_grid)

    return new_grid,changed

#function to perform move right
def move_right(grid):
    new_grid= reverse(grid)
    new_grid, changed = move_left(new_grid)
    new_grid = reverse(new_grid)
    return new_grid,changed

#function to perform move up
def move_up(grid):
    new_grid= transpose(grid)
    new_grid,changed=move_left(new_grid)
    new_grid=transpose(new_grid)
    return new_grid,changed

#Function to perform move down
def move_down(grid):
    new_grid=transpose(grid)
    new_grid,changed=move_right(new_grid)
    new_grid=transpose(new_grid)
    return new_grid,changed